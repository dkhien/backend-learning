# Banking App — Lab Starter Project

One Spring Boot app that you carry through all Java/Spring/Infra weeks.
The setup plumbing is done. **The learning content is not — that's your job.**

## What is pre-written (boilerplate)
- `pom.xml` — all dependencies for all weeks
- `application.yml` — connection config, commented switches per week
- Entity classes with `@Entity` mapping to Week 1 tables — getters/setters only
- Repository interfaces as empty stubs
- `LabController.java` with TODO comments — you implement the methods
- Liquibase changelog wiring — you write the actual changeSets

## What you write yourself (the learning)
- All TODO methods in `LabController.java`
- `@OneToMany` / `@ManyToOne` JPA relationships on entities (Week 3)
- `findAllWithTransactions()` JOIN FETCH query (Week 3)
- Your own Spring components: `BeanPostProcessor`, `PaymentService`, `AuditService` (Weeks 7–8)
- Liquibase changeSets in `db/changelog/changes/` (Week 2)
- `Dockerfile` and `docker-compose.yml` (Week 9)
- K8s deployment YAML (Week 10)

## Getting started

1. Make sure Postgres is running (from Week 1):
   ```bash
   docker start pg-lab
   ```

2. Open the project in IntelliJ and run `BankingAppApplication`.
   It will fail if Week 1 seeding is not done (Liquibase validates the schema).

3. Confirm it starts:
   ```bash
   curl http://localhost:8080/actuator/health
   ```

## Week-by-week switches in application.yml

| Week | What to change |
|------|---------------|
| W3 HikariCP | `hikari.maximum-pool-size: 3` (already set) — change to observe |
| W3 N+1 | Set `jpa.show-sql: true`, set `org.hibernate.SQL: DEBUG` |
| W5 GC | Add JVM flags to IntelliJ VM Options (see plan) |
| W6 Leak | Add JVM flags to IntelliJ VM Options (see plan) |
| W13 Redis | Change `spring.cache.type: none` → `redis` |

## Liquibase (Week 2 lab)

The `db/changelog/` folder is wired up. The `001` changeSet confirms
your Week 1 schema is in place (no-op).

Your exercise: add changeSets `002`, `003`, etc. in `db/changelog/changes/`.
The lab steps in the plan tell you what each changeSet should do.
