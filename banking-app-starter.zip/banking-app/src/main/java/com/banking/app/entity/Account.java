package com.banking.app.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Maps to the 'accounts' table seeded in Week 1.
 *
 * Week 3 lab: you will add the @OneToMany relationship to Transaction here.
 * Leave this class as-is until you reach that lab step.
 */
@Entity
@Table(name = "accounts")
public class Account {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "customer_id")
    private Integer customerId;

    @Column(name = "account_no", unique = true)
    private String accountNo;

    private BigDecimal balance;

    @Column(name = "branch_id")
    private Integer branchId;

    @Column(name = "opened_at")
    private LocalDate openedAt;

    // TODO Week 3 lab: add @OneToMany relationship to Transaction here

    public Long getId() { return id; }
    public String getAccountNo() { return accountNo; }
    public BigDecimal getBalance() { return balance; }
    public void setBalance(BigDecimal b) { this.balance = b; }
    public Integer getCustomerId() { return customerId; }
    public Integer getBranchId() { return branchId; }
    public LocalDate getOpenedAt() { return openedAt; }
}
