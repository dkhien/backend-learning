package com.banking.app.repository;

import com.banking.app.entity.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TransactionRepository extends JpaRepository<Transaction, Long> {
    // TODO: add query methods as needed in labs
}
