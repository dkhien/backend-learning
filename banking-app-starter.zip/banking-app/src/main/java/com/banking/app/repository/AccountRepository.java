package com.banking.app.repository;

import com.banking.app.entity.Account;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Week 3 lab: you will add query methods here.
 * - findAll() is inherited from JpaRepository — use this first to observe N+1
 * - Then add a JOIN FETCH query to fix it (lab step 2)
 */
public interface AccountRepository extends JpaRepository<Account, Long> {
    // TODO Week 3: add findAllWithTransactions() using @Query with JOIN FETCH
}
