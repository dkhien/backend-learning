package com.banking.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.sql.DataSource;

/**
 * Lab endpoints — add your implementations here as you progress through the plan.
 *
 * Each TODO block tells you which week it belongs to.
 * The setup (annotations, injection) is provided so you can focus on the logic.
 */
@RestController
public class LabController {

    @Autowired
    private DataSource dataSource;

    // ── Week 3: HikariCP pool exhaustion ──────────────────────────────────────
    // TODO: implement an endpoint that acquires a DB connection and holds it
    // for 2 seconds using SELECT pg_sleep(2). Hit it with 10 concurrent requests.
    @GetMapping("/slow")
    public String slow() throws Exception {
        // your implementation here
        return "not implemented yet";
    }

    // ── Week 5: GC stress ─────────────────────────────────────────────────────
    // TODO: implement an endpoint that allocates and frees byte arrays in a loop
    // to generate GC pressure. Goal: trigger both Minor and Full GC events.
    @GetMapping("/gc-stress")
    public String gcStress() throws InterruptedException {
        // your implementation here
        return "not implemented yet";
    }

    // ── Week 6: Memory leak ───────────────────────────────────────────────────
    // TODO: implement an endpoint that accumulates data on every request and
    // never cleans it up. The leak should be detectable with jstat and heap dump.
    @GetMapping("/leak")
    public String leak() {
        // your implementation here
        return "not implemented yet";
    }

    // ── Week 6: Thread dump ───────────────────────────────────────────────────
    // TODO: implement an endpoint that holds a thread for 30 seconds.
    // Take jstack while requests are in-flight to capture the thread state.
    @GetMapping("/hold")
    public String hold() throws InterruptedException {
        // your implementation here
        return "not implemented yet";
    }
}
