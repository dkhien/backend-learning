package com.banking.app.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

/**
 * Maps to the 'transactions' table seeded in Week 1.
 *
 * Week 3 lab: you will add the @ManyToOne relationship to Account here.
 */
@Entity
@Table(name = "transactions")
public class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "account_id")
    private Long accountId;   // simple FK for now — Week 3: replace with @ManyToOne

    @Column(name = "txn_type")
    private String txnType;

    private BigDecimal amount;
    private String status;

    @Column(name = "created_at")
    private OffsetDateTime createdAt;

    @Column(name = "reference_no")
    private String referenceNo;

    @Column(name = "branch_id")
    private Integer branchId;

    public Long getId() { return id; }
    public Long getAccountId() { return accountId; }
    public BigDecimal getAmount() { return amount; }
    public String getStatus() { return status; }
    public String getTxnType() { return txnType; }
    public OffsetDateTime getCreatedAt() { return createdAt; }
    public String getReferenceNo() { return referenceNo; }
}
