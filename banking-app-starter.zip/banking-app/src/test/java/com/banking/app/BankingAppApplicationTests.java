package com.banking.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankingAppApplicationTests {

    @Test
    void contextLoads() {
        // Verifies Spring context starts without errors
        // Run this to confirm your setup is correct before starting Week 3
    }
}
